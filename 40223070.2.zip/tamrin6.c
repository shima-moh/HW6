#include<stdio.h>
#include<math.h>

void solver(float,float,float,float *,float *);
int main()
{
    
     float a,b,c;
     printf("enter a,b,c\n");
     scanf("%f%f%f",&a,&b,&c);
     float T=b*b-4*a*c;
     float x1,x2;
     float *p1=&x1;
     float *p2=&x2;
     if(a==0 && b==0)
        printf("wrong numbers");
     else 
     {
        if(T>0)
        {
            solver(a,b,c,p1,p2);
            printf("number of roots:2\n roots:\n%f\n%f\n",*p1,*p2);
        }
        else if(T==0 || a==0)
        {
            solver(a,b,c,p1,p2);
            printf("number of roots=1\n root:%f\n",*p1);
        }
        else
            printf("This equation has no real roots");
     }  
    
}
void solver(float a,float b,float c,float *p1,float *p2)
{
    float T=b*b-4*a*c;
    if(a==0)
        *p1=-(c/b);
    else if(T>0)
    {
        *p1=((-b)-sqrt(T))/(2*a);
        *p2=((-b)+sqrt(T))/(2*a);
       
    }
    else if(T==0)
        *p1=-(b/(2*a));
}